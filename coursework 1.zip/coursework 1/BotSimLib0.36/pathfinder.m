function waypoint_coordinates = pathfinder(start_point, end_point, external_boundaries)

% Function which finds the shortest path from a start point to an end point 
% in a 2D arena whilst avoiding obstacles. This function uses Visibility
% Graphs elements to implement the Dijkstra's algorithm.

%% Initialize empty arrays
initial_combined_nodes = zeros(size(external_boundaries,1)+2,3);

%% Create the inital set of unvisited nodes
initial_combined_nodes(1,1:2) = [start_point(1), start_point(2)];
initial_combined_nodes(2:size(external_boundaries,1)+1,1:2) = external_boundaries;
initial_combined_nodes(size(external_boundaries,1)+2,1:2) = [end_point(1), end_point(2)];

%% Assign infinte tentative distances to all nodes excpet the initial node
initial_combined_nodes(:,3) = Inf*ones(size(initial_combined_nodes,1),1);

%% Determine which nodes are visible from the initial node / starting point
visible_nodes_ID = zeros(1,size(initial_combined_nodes,1));

%% Compile a library of all neighbouring nodes which are visible from the current node
% First, initialise this library as an empty 3D array 
visible_neighbours_library =  zeros(size(initial_combined_nodes,1),size(initial_combined_nodes,2),size(initial_combined_nodes,1));

% Set all the Index values of visible node to 0
visible_index = 0;

for reference_node_ID = 1:size(initial_combined_nodes,1)
    combined_nodes = initial_combined_nodes;    
    for target_ID = 1:size(initial_combined_nodes,1)
        % Initialise the observer and target (endpoint) nodes
        observer_state = initial_combined_nodes(reference_node_ID,:);
        current_target_node = initial_combined_nodes(target_ID,:);
        
        % This checks whether or not the target node is visible from the observer node 
        visibility = line_of_sight(observer_state, current_target_node, external_boundaries);
        % if it is visible, visibility is set to 1
        if visibility == 1 %If target is visible
            
            % The ID of the visible node is then recorded
            visible_index = visible_index + 1;
            visible_nodes_ID(visible_index) = target_ID;
            combined_nodes(target_ID,3) = sqrt((current_target_node(1) - observer_state(1))^2 + (current_target_node(2) - observer_state(2))^2);
                        
        end
        
    end
    
    % Compile a 3D library of all the visible neighbouring nodes with respect to a reference node
    visible_neighbours_library(:,:,reference_node_ID) = combined_nodes;
    
end

%% Next, the unvisited nodes are intialised
unvisited_nodes = zeros(1,size(initial_combined_nodes,1));

%% Next, a list of all the unvisisted nodes is compiled so that they may be assigned to the unvisited node set
for index = 1:size(initial_combined_nodes)
    unvisited_nodes(index) = index;
end

shortest_path_array = visible_neighbours_library(:,:,1);

%% We intialise the starting node to 1
shortest_path_array(:,4) = 1;

%% We now need to remove the starting node from the univisted node set
current_node = 1;
unvisited_nodes = setdiff(unvisited_nodes, current_node);

%% the loop below represents the reallocation of the starting node and the removal of the 
% visited nodes from the univsisted node set until the target node has been visited or the 
% conditions have been met
while size(unvisited_nodes,2) > 0
    
    % The next starting node / current node is node with the smallest cumulative distance
    cumulative_distances = shortest_path_array(unvisited_nodes,3);
    [~, current_node_ID_index] = min(cumulative_distances); %First output (~) is not used
    
    % The current node is then extraced
    current_node_ID = unvisited_nodes(current_node_ID_index);
    
    % This line of code removes the current node from the set of unvisited node
    unvisited_nodes = setdiff(unvisited_nodes, current_node_ID);
    
    
    for unvisited_node_index = 1:size(unvisited_nodes,2)
        
        % An univisited node is set as the next target node
        target_node_ID = unvisited_nodes(unvisited_node_index);
        
        % if the distance between the target node and the current node is less than inifinty, then visibility is assumed
        if visible_neighbours_library(target_node_ID,3,current_node_ID) < Inf
            
            % the cumulative or tentaive distance for the target node is now computed
            cumulative_distance_to_current_node = shortest_path_array(current_node_ID,3);
            distance_from_current_to_target_node = visible_neighbours_library(target_node_ID,3,current_node_ID);
            new_cumulative_distance = cumulative_distance_to_current_node + distance_from_current_to_target_node;
            
            % In order to compare this value to the previous, the previous value has to be determined
            previous_cumulative_distance_to_target_node = shortest_path_array(target_node_ID,3);
            
            % if a s maller distance value  is found from the comparison
            if new_cumulative_distance < previous_cumulative_distance_to_target_node
                
                % then we need to replace the previous value with the smaller one
                shortest_path_array(target_node_ID,3) = new_cumulative_distance;    
 
                shortest_path_array(target_node_ID,4) = current_node_ID;
                
            end
            
        end
        
    end
    
end


%% Finally, now we can identify the shortest path 
path = zeros(1,size(shortest_path_array,1));

% We need to save the path starting with the target node
path_index = 1;
path(path_index) = size(initial_combined_nodes,1);

while path(path_index) > 1 % this is repeated until the starting node is reached
    
    path_index = path_index + 1;
    path(path_index) = shortest_path_array(path(path_index-1),4);
    
end

%% Now we can reverse the order of the saved path so that a path is printing 
path = fliplr(path(1:path_index));

%% Now for the final part we can extract the waypoint coordinates from this newly 
% constructed path array to be used in the rest of the code
waypoint_coordinates(:,1) = initial_combined_nodes(path,1);
waypoint_coordinates(:,2) = initial_combined_nodes(path,2);
end 